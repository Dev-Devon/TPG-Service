<?php
set_time_limit(0);

header("Content-Type: text/plain");

ob_implicit_flush(true);
if (ob_get_level()) {
    ob_end_flush();
}

$savePath   = $_POST['path'] ?? '';
$url        = $_POST['url'] ?? '';
$resolution = $_POST['resolution'] ?? '';
$video      = $_POST['video'] ?? '0';
$audio      = $_POST['audio'] ?? '0';

if (!$savePath) {
    echo "Invalid save path\n";
    exit;
}

if (!is_dir($savePath)) {
    mkdir($savePath, 0777, true);
}

$urls = [];

if (!empty($_FILES['batchFile']['tmp_name'])) {

    $file = file($_FILES['batchFile']['tmp_name']);

    foreach ($file as $line) {
        $line = trim($line);
        if ($line !== '') {
            $urls[] = $line;
        }
    }

} elseif (!empty($url)) {

    $urls[] = trim($url);

}

if (empty($urls)) {
    echo "No URLs provided\n";
    exit;
}

$ds = DIRECTORY_SEPARATOR;

foreach ($urls as $u) {

    echo "Processing: $u\n";

    $cleanPath  = rtrim($savePath, '/\\');
    $outputPath = $cleanPath . $ds . '%(title)s.%(ext)s';

    if ($video === "1") {

        $res = intval($resolution);

        if ($res <= 0) {
            $res = 1080;
        }

        /*
        Format priority:

        1. H264 video + AAC audio at requested resolution
        2. H264 + AAC lower resolution
        3. best mp4 combined
        4. best anything
        */

        $format =
            "bestvideo[vcodec^=avc1][height<=$res]+bestaudio[acodec^=mp4a]" .
            "/bestvideo[vcodec^=avc1]+bestaudio[acodec^=mp4a]" .
            "/best[ext=mp4]" .
            "/best";

        $cmd =
            "yt-dlp -f \"$format\" " .
            "--merge-output-format mp4 " .
            "--restrict-filenames " .
            "-o \"$outputPath\" \"$u\" 2>&1";

        passthru($cmd, $exitCode);

        if ($exitCode !== 0) {
            echo "Video download failed\n";
        }
    }

    if ($audio === "1") {

        $cmd =
            "yt-dlp -x --audio-format mp3 " .
            "--restrict-filenames " .
            "-o \"$outputPath\" \"$u\" 2>&1";

        passthru($cmd, $exitCode);

        if ($exitCode !== 0) {
            echo "Audio download failed\n";
        }
    }

    echo "Finished: $u\n";
}

echo "All tasks done\n";
?>